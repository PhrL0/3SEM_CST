#ifndef SENSOR_TEMP_H
#define SENSOR_TEMP_H

void startTemperature();
float readTemperature();

#endif